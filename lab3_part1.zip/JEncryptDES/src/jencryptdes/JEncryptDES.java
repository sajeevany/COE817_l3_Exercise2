/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jencryptdes;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;


/**
 *
 * @author a2mahend
 */
public class JEncryptDES {

 /**
  * @param args the command line arguments
  */
 public static void main(String[] args) {
  // TODO code application logic here
   Scanner in = new Scanner(System.in);
   System.out.println("Type Message to encrpyt (No body can see me):");
   String message = in .nextLine();
   try {
    //init keygenerator, Object contains functionality to create keys
    KeyGenerator keygen = KeyGenerator.getInstance("DES");
    // generate key
    SecretKey DESkey = keygen.generateKey();

    //Cipher object contains Cryptographic cipher functionality
    Cipher desObject;
    // Specify Cipher params
    // DES, ECB Electronic Codebook mode, PKCS5Padding means With Padding, 
    desObject = Cipher.getInstance("DES/ECB/PKCS5Padding");

    //convert message to byte array, Cipher Methods take Byte Arrays as parameters
    
    byte[] messageBytes = message.getBytes();
    //init cipher encrpyt more with Generated key
    desObject.init(Cipher.ENCRYPT_MODE, DESkey);
    // doFinal runs multi part Encryption 
    byte[] bytesEncrypted = desObject.doFinal(messageBytes);
     String encryptedText = new String(bytesEncrypted, "UTF-8");

    // init and execute Decypher mode, using same key
    desObject.init(Cipher.DECRYPT_MODE, DESkey);
    byte[] bytesDecrypted = desObject.doFinal(bytesEncrypted);
    
    // Converts Bytes to output string
    String outputText = new String(bytesDecrypted, "UTF-8");

    System.out.println("Encoded message(Bytes): " + bytesEncrypted);
    System.out.println("Encoded message(String): " + encryptedText);
    System.out.println("Decoded message: " + outputText);


   } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException | UnsupportedEncodingException e) {
       System.out.println(e);
   }
    
     
 }

}