/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jencryptrsa;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.Scanner;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author a2mahend
 */
public class JEncryptRSA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        // TODO code application logic here
//          String pub_exp = "65537";
//    String modulus  = "89489425009274444368228545921773093919669586065884257445497854456487674839629818390934941973262879616797970608917283679875499331574161113854088813275488110588247193077582527278437906504015680623423550067240042466665654232383502922215493623289472138866445818789127946123407807725702626644091036502372545139713";
//    
      
        int keySize = 512;  
        SecureRandom random = new SecureRandom();
        // Choose two distinct prime numbers p and q.
        BigInteger p = BigInteger.probablePrime(keySize/2,random);
        BigInteger q = BigInteger.probablePrime(keySize/2,random);
        // Compute n = pq (modulus)
        BigInteger modulus = p.multiply(q);
        // Compute φ(n) = φ(p)φ(q) = (p − 1)(q − 1) = n - (p + q -1), where φ is Euler's totient function.
        // and choose an integer e such that 1 < e < φ(n) and gcd(e, φ(n)) = 1; i.e., e and φ(n) are coprime.
        BigInteger m = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
        BigInteger publicExponent;
        publicExponent = getCoprime(m,random);
        // Determine d as d ≡ e−1 (mod φ(n)); i.e., d is the multiplicative inverse of e (modulo φ(n)).
        BigInteger privateExponent = publicExponent.modInverse(m);
        
        
        Scanner in = new Scanner(System.in);
   System.out.println("Type Message to encrpyt (No body can see me):");
   String message = in .nextLine();
   byte[] messageBytes = message.getBytes();

   
//    System.arraycopy(messageBytes, 0, resultMessage, 0,  messageBytes.length);
//    System.arraycopy(padding, 0, resultMessage, messageBytes.length, padding.length);

  // messageBytes.insert(0, (byte) 0xbe);
   
    
        Cipher cipher = Cipher.getInstance("RSA/ECB/NoPadding");
        
         KeyFactory keyFactory = KeyFactory.getInstance("RSA");
         RSAPublicKeySpec pubKeySpec = new RSAPublicKeySpec(modulus, publicExponent);
         
         RSAPrivateKeySpec privKeySpec = new RSAPrivateKeySpec(modulus, privateExponent);
         
       //  System.out.println(privKeySpec.length());
         
       //  System.out.println("Decoded message: " + outputText);
         
         
        RSAPublicKey pubKey = (RSAPublicKey) keyFactory.generatePublic(pubKeySpec);
        RSAPrivateKey privKey = (RSAPrivateKey) keyFactory.generatePrivate(privKeySpec);
        
//        System.out.println(privKey);
//        System.out.println(pubKey);
        
        cipher.init(Cipher.ENCRYPT_MODE, pubKey);
    
    byte[] cipherText = cipher.doFinal(messageBytes);
    String cipherTextReadable = new String(cipherText, "UTF-8");
    System.out.println("cipher: " + cipherTextReadable);

    cipher.init(Cipher.DECRYPT_MODE, privKey);
    
    
    byte[] plainText = cipher.doFinal(cipherText);
    String outputText = new String(plainText, "UTF-8");
    System.out.println("plain : " + outputText);
        
        
    }

    private static BigInteger getCoprime(BigInteger m, SecureRandom random) {
//           Random rnd = new Random();
      int length = m.bitLength()-1;
      BigInteger e = BigInteger.probablePrime(length,random);
      while (! (m.gcd(e)).equals(BigInteger.ONE) ) {
      	 e = BigInteger.probablePrime(length,random);
      }
      return e;
    }
}
